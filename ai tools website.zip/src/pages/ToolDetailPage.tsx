import { useParams, Link } from 'react-router-dom';
import { useMemo } from 'react';
import { ChevronRight, Star, ExternalLink, Check, X, ArrowRight } from 'lucide-react';
import AdUnit from '../components/AdUnit';
import ToolCard from '../components/ToolCard';
import { tools, categories } from '../lib/tools-data';

export default function ToolDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  
  const tool = useMemo(() => tools.find(t => t.slug === slug), [slug]);
  const category = useMemo(() => {
    if (!tool) return null;
    return categories.find(cat => cat.id === tool.category);
  }, [tool]);
  
  const relatedTools = useMemo(() => {
    if (!tool) return [];
    return tools
      .filter(t => t.category === tool.category && t.id !== tool.id)
      .slice(0, 3);
  }, [tool]);

  if (!tool || !category) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <h1 className="text-3xl font-bold text-foreground mb-4">Tool Not Found</h1>
        <Link to="/" className="text-primary hover:underline">
          Return to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-secondary border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="flex items-center gap-2 text-sm">
            <Link to="/" className="text-muted-foreground hover:text-primary transition">
              Home
            </Link>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
            <Link to={`/category/${category.slug}`} className="text-muted-foreground hover:text-primary transition">
              {category.name}
            </Link>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
            <span className="text-foreground font-medium">{tool.name}</span>
          </nav>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Header */}
            <div>
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-4xl font-bold text-foreground mb-2">{tool.name}</h1>
                  <p className="text-xl text-muted-foreground mb-4">{tool.tagline}</p>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold text-foreground">{tool.rating}</span>
                      <span className="text-muted-foreground">({tool.reviewCount} reviews)</span>
                    </div>
                    <Link
                      to={`/category/${category.slug}`}
                      className="px-3 py-1 bg-primary/10 text-primary text-sm font-medium rounded-full hover:bg-primary/20 transition"
                    >
                      {category.name}
                    </Link>
                  </div>
                </div>
              </div>

              <img
                src={tool.image}
                alt={tool.name}
                className="w-full aspect-video object-cover rounded-lg"
              />
            </div>

            {/* CTA */}
            <div className="bg-primary/5 border-2 border-primary rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-lg font-semibold text-foreground mb-1">Try {tool.name} Today</p>
                  <p className="text-sm text-muted-foreground">{tool.pricing}</p>
                </div>
                <a
                  href={tool.affiliateLink || tool.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-primary text-white font-semibold rounded-lg hover:opacity-90 transition flex items-center gap-2"
                >
                  Visit Website
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>

            {/* Ad Unit */}
            <AdUnit slot="2222222222" format="rectangle" />

            {/* Description */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">About {tool.name}</h2>
              <p className="text-foreground leading-relaxed mb-4">{tool.description}</p>
              <p className="text-foreground leading-relaxed">{tool.longDescription}</p>
            </div>

            {/* Features */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Key Features</h2>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {tool.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Pros & Cons */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-bold text-foreground mb-4">Pros</h3>
                <ul className="space-y-2">
                  {tool.pros.map((pro, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                      <span className="text-foreground">{pro}</span>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-bold text-foreground mb-4">Cons</h3>
                <ul className="space-y-2">
                  {tool.cons.map((con, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <X className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                      <span className="text-foreground">{con}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Use Cases */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Perfect For</h2>
              <div className="flex flex-wrap gap-2">
                {tool.useCases.map((useCase, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-secondary border border-border rounded-full text-sm text-foreground"
                  >
                    {useCase}
                  </span>
                ))}
              </div>
            </div>

            {/* Ad Unit */}
            <AdUnit slot="3333333333" format="horizontal" />

            {/* FAQ Schema */}
            <div>
              <h2 className="text-2xl font-bold text-foreground mb-4">Frequently Asked Questions</h2>
              <div className="space-y-4">
                <div className="border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">What is {tool.name}?</h3>
                  <p className="text-muted-foreground">{tool.description}</p>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">How much does {tool.name} cost?</h3>
                  <p className="text-muted-foreground">{tool.pricing}</p>
                </div>
                <div className="border border-border rounded-lg p-4">
                  <h3 className="font-semibold text-foreground mb-2">Is {tool.name} worth it?</h3>
                  <p className="text-muted-foreground">
                    With a {tool.rating} rating from {tool.reviewCount} users, {tool.name} is highly regarded
                    for {tool.useCases.slice(0, 2).join(' and ')}.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            {/* Sticky Ad */}
            <div className="sticky top-20">
              <AdUnit slot="4444444444" format="vertical" />
            </div>

            {/* Tool Info */}
            <div className="bg-secondary border border-border rounded-lg p-6 space-y-4">
              <h3 className="font-bold text-foreground">Tool Information</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <span className="text-muted-foreground">Category:</span>
                  <Link to={`/category/${category.slug}`} className="ml-2 text-primary hover:underline">
                    {category.name}
                  </Link>
                </div>
                <div>
                  <span className="text-muted-foreground">Pricing:</span>
                  <span className="ml-2 text-foreground font-medium">{tool.pricing}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Rating:</span>
                  <span className="ml-2 text-foreground font-medium">{tool.rating}/5</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Reviews:</span>
                  <span className="ml-2 text-foreground font-medium">{tool.reviewCount}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Last Updated:</span>
                  <span className="ml-2 text-foreground font-medium">{tool.updatedAt}</span>
                </div>
              </div>
              <a
                href={tool.affiliateLink || tool.website}
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full px-4 py-3 bg-primary text-white text-center font-semibold rounded-lg hover:opacity-90 transition"
              >
                Visit {tool.name} →
              </a>
            </div>

            {/* Related Tools */}
            {relatedTools.length > 0 && (
              <div>
                <h3 className="font-bold text-foreground mb-4">Related Tools</h3>
                <div className="space-y-4">
                  {relatedTools.map((relatedTool) => (
                    <Link
                      key={relatedTool.id}
                      to={`/tool/${relatedTool.slug}`}
                      className="block bg-card border border-border rounded-lg p-4 hover:shadow-lg hover:border-primary transition"
                    >
                      <h4 className="font-semibold text-foreground mb-1">{relatedTool.name}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                        {relatedTool.tagline}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1">
                          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                          <span className="text-xs font-medium">{relatedTool.rating}</span>
                        </div>
                        <ArrowRight className="w-4 h-4 text-primary" />
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
