import { useState } from 'react';
import { Send } from 'lucide-react';

export default function SubmitToolPage() {
  const [formData, setFormData] = useState({
    toolName: '',
    website: '',
    category: '',
    description: '',
    pricing: '',
    email: '',
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Tool submission:', formData);
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setFormData({
        toolName: '',
        website: '',
        category: '',
        description: '',
        pricing: '',
        email: '',
      });
    }, 3000);
  };

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-4">Submit Your AI Tool</h1>
          <p className="text-lg text-muted-foreground">
            Have an AI tool to share? Submit it here and we'll review it for inclusion in our directory.
          </p>
        </div>

        {submitted ? (
          <div className="bg-green-50 border border-green-200 rounded-lg p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Send className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-green-900 mb-2">Submission Received!</h2>
            <p className="text-green-700">
              Thank you for your submission. We'll review your tool and get back to you within 3-5 business days.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="bg-card border border-border rounded-lg p-8 space-y-6">
            <div>
              <label htmlFor="toolName" className="block text-sm font-medium text-foreground mb-2">
                Tool Name *
              </label>
              <input
                type="text"
                id="toolName"
                required
                value={formData.toolName}
                onChange={(e) => setFormData({ ...formData, toolName: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Enter the name of your AI tool"
              />
            </div>

            <div>
              <label htmlFor="website" className="block text-sm font-medium text-foreground mb-2">
                Website URL *
              </label>
              <input
                type="url"
                id="website"
                required
                value={formData.website}
                onChange={(e) => setFormData({ ...formData, website: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="https://yourtool.com"
              />
            </div>

            <div>
              <label htmlFor="category" className="block text-sm font-medium text-foreground mb-2">
                Category *
              </label>
              <select
                id="category"
                required
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
              >
                <option value="">Select a category</option>
                <option value="writing">AI Writing</option>
                <option value="design">AI Design</option>
                <option value="coding">AI Coding</option>
                <option value="video">AI Video</option>
                <option value="marketing">AI Marketing</option>
                <option value="productivity">AI Productivity</option>
                <option value="audio">AI Audio</option>
                <option value="research">AI Research</option>
              </select>
            </div>

            <div>
              <label htmlFor="description" className="block text-sm font-medium text-foreground mb-2">
                Description *
              </label>
              <textarea
                id="description"
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={5}
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="Describe what your tool does and its key features..."
              />
            </div>

            <div>
              <label htmlFor="pricing" className="block text-sm font-medium text-foreground mb-2">
                Pricing *
              </label>
              <input
                type="text"
                id="pricing"
                required
                value={formData.pricing}
                onChange={(e) => setFormData({ ...formData, pricing: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="e.g., Free plan, Pro from $29/month"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                Your Email *
              </label>
              <input
                type="email"
                id="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                placeholder="your@email.com"
              />
            </div>

            <div className="pt-4">
              <button
                type="submit"
                className="w-full px-6 py-4 bg-primary text-white font-semibold rounded-lg hover:opacity-90 transition flex items-center justify-center gap-2"
              >
                <Send className="w-5 h-5" />
                Submit Tool for Review
              </button>
            </div>

            <p className="text-sm text-muted-foreground text-center">
              By submitting, you agree to our review process. We typically respond within 3-5 business days.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
