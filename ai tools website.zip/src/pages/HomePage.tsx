import { useState, useMemo } from 'react';
import { Search, TrendingUp, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';
import ToolCard from '../components/ToolCard';
import AdUnit from '../components/AdUnit';
import { tools, categories } from '../lib/tools-data';

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState('');

  const trendingTools = useMemo(() => tools.filter(tool => tool.trending).slice(0, 6), []);
  const featuredTools = useMemo(() => tools.filter(tool => tool.featured).slice(0, 8), []);

  const filteredTools = useMemo(() => {
    if (!searchQuery) return tools;
    const query = searchQuery.toLowerCase();
    return tools.filter(
      tool =>
        tool.name.toLowerCase().includes(query) ||
        tool.description.toLowerCase().includes(query) ||
        tool.category.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-background to-secondary py-16 sm:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
              <Sparkles className="w-4 h-4" />
              50+ AI Tools Curated
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground text-balance">
              Discover the Best AI Tools in 2026
            </h1>
            <p className="text-lg sm:text-xl text-muted-foreground text-balance">
              Explore carefully curated AI tools for writing, design, coding, marketing, and more. Find the perfect AI solution to supercharge your workflow.
            </p>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto pt-4">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  placeholder="Search AI tools by name, category, or use case..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 text-base border-2 border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Ad Unit - Leaderboard */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <AdUnit slot="1234567890" format="horizontal" className="mx-auto max-w-4xl" />
      </div>

      {/* Trending Tools */}
      {!searchQuery && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="flex items-center gap-3 mb-8">
            <TrendingUp className="w-6 h-6 text-primary" />
            <h2 className="text-3xl font-bold text-foreground">Trending This Week</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trendingTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>
        </section>
      )}

      {/* Categories */}
      {!searchQuery && (
        <section className="bg-secondary py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-foreground mb-8">Browse by Category</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  to={`/category/${category.slug}`}
                  className="group bg-card border border-border rounded-lg p-6 hover:shadow-lg hover:border-primary transition-all"
                >
                  <h3 className="font-semibold text-foreground group-hover:text-primary transition mb-2">
                    {category.name}
                  </h3>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {category.description}
                  </p>
                  <div className="mt-4 text-sm text-primary font-medium">
                    Explore →
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Ad Unit - Rectangle */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <AdUnit slot="0987654321" format="rectangle" className="mx-auto max-w-md" />
      </div>

      {/* Featured/All Tools */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <h2 className="text-3xl font-bold text-foreground mb-8">
          {searchQuery ? `Search Results (${filteredTools.length})` : 'Featured AI Tools'}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {(searchQuery ? filteredTools : featuredTools).map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>

        {!searchQuery && (
          <div className="text-center mt-12">
            <p className="text-muted-foreground mb-4">Want to see all {tools.length} AI tools?</p>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="px-6 py-3 bg-primary text-white font-medium rounded-lg hover:opacity-90 transition"
            >
              Search or Browse Categories
            </button>
          </div>
        )}

        {searchQuery && filteredTools.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">No tools found matching "{searchQuery}"</p>
            <button
              onClick={() => setSearchQuery('')}
              className="mt-4 text-primary font-medium hover:underline"
            >
              Clear search
            </button>
          </div>
        )}
      </section>
    </div>
  );
}
