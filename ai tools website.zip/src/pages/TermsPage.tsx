export default function TermsPage() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-foreground mb-8">Terms of Service</h1>
        
        <div className="prose prose-lg max-w-none space-y-8 text-foreground">
          <section>
            <h2 className="text-2xl font-bold mb-4">Agreement to Terms</h2>
            <p className="text-muted-foreground leading-relaxed">
              By accessing and using AI Tools Directory, you agree to be bound by these Terms of Service and all
              applicable laws and regulations. If you do not agree with any of these terms, you are prohibited
              from using this site.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Use License</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Permission is granted to temporarily access the materials on AI Tools Directory for personal,
              non-commercial use only. This is the grant of a license, not a transfer of title, and under this
              license you may not:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Modify or copy the materials</li>
              <li>Use the materials for any commercial purpose</li>
              <li>Attempt to reverse engineer any software on the website</li>
              <li>Remove any copyright or proprietary notations</li>
              <li>Transfer the materials to another person or mirror on another server</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Tool Listings Disclaimer</h2>
            <p className="text-muted-foreground leading-relaxed">
              The AI tools listed on this website are provided for informational purposes only. We do not endorse,
              guarantee, or assume responsibility for any third-party products or services. Reviews, ratings, and
              descriptions are based on publicly available information and user submissions.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Affiliate Disclosure</h2>
            <p className="text-muted-foreground leading-relaxed">
              AI Tools Directory may contain affiliate links to third-party tools and services. When you click on
              these links and make a purchase, we may receive a commission at no additional cost to you. This helps
              support our website and allows us to continue providing valuable content.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">User-Submitted Content</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              By submitting content (including tool submissions, reviews, or comments) to our website, you grant
              us a non-exclusive, worldwide, royalty-free license to use, reproduce, and display that content. You
              represent that:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>You own or have permission to use the submitted content</li>
              <li>The content does not violate any third-party rights</li>
              <li>The content is accurate and not misleading</li>
              <li>The content complies with all applicable laws</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Advertising</h2>
            <p className="text-muted-foreground leading-relaxed">
              This website displays advertisements from third-party networks including Google AdSense and Adsterra.
              We do not control the content of these advertisements and are not responsible for any products or
              services advertised.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Disclaimer of Warranties</h2>
            <p className="text-muted-foreground leading-relaxed">
              The materials on AI Tools Directory are provided on an "as is" basis. We make no warranties, expressed
              or implied, and hereby disclaim all other warranties including, without limitation, implied warranties
              of merchantability, fitness for a particular purpose, or non-infringement of intellectual property.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Limitations of Liability</h2>
            <p className="text-muted-foreground leading-relaxed">
              In no event shall AI Tools Directory or its suppliers be liable for any damages (including, without
              limitation, damages for loss of data or profit) arising out of the use or inability to use the materials
              on this website, even if we have been notified of the possibility of such damage.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Accuracy of Materials</h2>
            <p className="text-muted-foreground leading-relaxed">
              The materials appearing on AI Tools Directory could include technical, typographical, or photographic
              errors. We do not warrant that any of the materials on the website are accurate, complete, or current.
              We may make changes to the materials at any time without notice.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">External Links</h2>
            <p className="text-muted-foreground leading-relaxed">
              AI Tools Directory has not reviewed all of the sites linked to its website and is not responsible for
              the contents of any such linked site. The inclusion of any link does not imply endorsement by us. Use
              of any linked website is at the user's own risk.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Modifications</h2>
            <p className="text-muted-foreground leading-relaxed">
              We may revise these Terms of Service at any time without notice. By using this website, you are agreeing
              to be bound by the then-current version of these terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Governing Law</h2>
            <p className="text-muted-foreground leading-relaxed">
              These terms and conditions are governed by and construed in accordance with applicable laws, and you
              irrevocably submit to the exclusive jurisdiction of the courts in that location.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Contact Information</h2>
            <p className="text-muted-foreground leading-relaxed">
              If you have any questions about these Terms of Service, please contact us at terms@aitoolsdirectory.com
            </p>
          </section>

          <p className="text-sm text-muted-foreground pt-8 border-t border-border">
            Last updated: January 15, 2026
          </p>
        </div>
      </div>
    </div>
  );
}
