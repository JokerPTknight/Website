import { useParams, Link } from 'react-router-dom';
import { useMemo } from 'react';
import { ChevronRight } from 'lucide-react';
import ToolCard from '../components/ToolCard';
import AdUnit from '../components/AdUnit';
import { tools, categories } from '../lib/tools-data';

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  
  const category = useMemo(() => categories.find(cat => cat.slug === slug), [slug]);
  const categoryTools = useMemo(() => {
    if (!category) return [];
    return tools.filter(tool => tool.category === category.id);
  }, [category]);

  if (!category) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 text-center">
        <h1 className="text-3xl font-bold text-foreground mb-4">Category Not Found</h1>
        <Link to="/" className="text-primary hover:underline">
          Return to Home
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Breadcrumb */}
      <div className="bg-secondary border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <nav className="flex items-center gap-2 text-sm">
            <Link to="/" className="text-muted-foreground hover:text-primary transition">
              Home
            </Link>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
            <Link to={`/category/${category.slug}`} className="text-foreground font-medium">
              {category.name}
            </Link>
          </nav>
        </div>
      </div>

      {/* Category Header */}
      <section className="bg-gradient-to-br from-primary/5 to-secondary py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl sm:text-5xl font-bold text-foreground mb-4">
              {category.name}
            </h1>
            <p className="text-lg text-muted-foreground mb-6">
              {category.description}
            </p>
            <p className="text-sm text-muted-foreground">
              {categoryTools.length} tools available
            </p>
          </div>
        </div>
      </section>

      {/* Ad Unit */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
        <AdUnit slot="1111111111" format="horizontal" className="mx-auto max-w-4xl" />
      </div>

      {/* Tools Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categoryTools.map((tool) => (
            <ToolCard key={tool.id} tool={tool} />
          ))}
        </div>

        {categoryTools.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground text-lg">No tools found in this category yet.</p>
          </div>
        )}
      </section>

      {/* Related Categories */}
      <section className="bg-secondary py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-bold text-foreground mb-6">Explore Other Categories</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {categories
              .filter(cat => cat.id !== category.id)
              .slice(0, 4)
              .map((cat) => (
                <Link
                  key={cat.id}
                  to={`/category/${cat.slug}`}
                  className="bg-card border border-border rounded-lg p-4 hover:shadow-lg hover:border-primary transition"
                >
                  <h3 className="font-semibold text-foreground mb-1">{cat.name}</h3>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {cat.description}
                  </p>
                </Link>
              ))}
          </div>
        </div>
      </section>
    </div>
  );
}
