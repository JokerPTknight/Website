export default function PrivacyPage() {
  return (
    <div className="min-h-screen py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl font-bold text-foreground mb-8">Privacy Policy</h1>
        
        <div className="prose prose-lg max-w-none space-y-8 text-foreground">
          <section>
            <h2 className="text-2xl font-bold mb-4">Introduction</h2>
            <p className="text-muted-foreground leading-relaxed">
              This Privacy Policy explains how AI Tools Directory collects, uses, and protects your personal information
              when you use our website. We are committed to ensuring your privacy is protected.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Information We Collect</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We may collect the following information:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Email address (when you subscribe to our newsletter)</li>
              <li>Tool submission information (name, website, description)</li>
              <li>Usage data and analytics (via Google Analytics)</li>
              <li>Cookie data for advertising purposes</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">How We Use Your Information</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              We use the collected information for:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Sending newsletter updates about new AI tools</li>
              <li>Processing tool submissions</li>
              <li>Improving our website and user experience</li>
              <li>Displaying relevant advertisements</li>
              <li>Analyzing website traffic and trends</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Advertising</h2>
            <p className="text-muted-foreground leading-relaxed">
              We use third-party advertising services including Google AdSense and Adsterra. These services may use
              cookies and web beacons to serve ads based on your browsing history. You can opt-out of personalized
              advertising by visiting the advertising network's privacy settings.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Cookies</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our website uses cookies to enhance user experience and serve relevant advertisements. You can choose
              to disable cookies through your browser settings, but this may affect some website functionality.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Data Security</h2>
            <p className="text-muted-foreground leading-relaxed">
              We implement appropriate security measures to protect your personal information. However, no method
              of transmission over the internet is 100% secure, and we cannot guarantee absolute security.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Third-Party Links</h2>
            <p className="text-muted-foreground leading-relaxed">
              Our website contains links to third-party AI tools. We are not responsible for the privacy practices
              or content of these external sites. We encourage you to review their privacy policies.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Your Rights</h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              You have the right to:
            </p>
            <ul className="list-disc list-inside space-y-2 text-muted-foreground">
              <li>Request access to your personal data</li>
              <li>Request correction of your personal data</li>
              <li>Request deletion of your personal data</li>
              <li>Opt-out of marketing communications</li>
              <li>Disable cookies through your browser settings</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Changes to This Policy</h2>
            <p className="text-muted-foreground leading-relaxed">
              We may update this privacy policy from time to time. Any changes will be posted on this page with
              an updated revision date.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold mb-4">Contact Us</h2>
            <p className="text-muted-foreground leading-relaxed">
              If you have any questions about this Privacy Policy, please contact us at privacy@aitoolsdirectory.com
            </p>
          </section>

          <p className="text-sm text-muted-foreground pt-8 border-t border-border">
            Last updated: January 15, 2026
          </p>
        </div>
      </div>
    </div>
  );
}
