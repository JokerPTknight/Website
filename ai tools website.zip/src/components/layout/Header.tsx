import { Link } from 'react-router-dom';
import { Search, Menu, Sparkles } from 'lucide-react';
import { useState } from 'react';
import { categories } from '../../lib/tools-data';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2 font-bold text-xl text-primary hover:opacity-80 transition">
            <Sparkles className="w-6 h-6" />
            <span>AI Tools Directory</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <Link to="/" className="text-sm font-medium text-foreground hover:text-primary transition">
              Home
            </Link>
            <div className="relative group">
              <button className="text-sm font-medium text-foreground hover:text-primary transition flex items-center gap-1">
                Categories
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              <div className="absolute left-0 mt-2 w-56 bg-white rounded-lg shadow-lg border border-border opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200">
                <div className="py-2">
                  {categories.map((category) => (
                    <Link
                      key={category.id}
                      to={`/category/${category.slug}`}
                      className="block px-4 py-2 text-sm text-foreground hover:bg-secondary transition"
                    >
                      {category.name}
                    </Link>
                  ))}
                </div>
              </div>
            </div>
            <Link to="/submit" className="text-sm font-medium text-foreground hover:text-primary transition">
              Submit Tool
            </Link>
          </nav>

          {/* Search Icon */}
          <button className="hidden md:flex items-center gap-2 px-4 py-2 text-sm bg-secondary rounded-lg hover:bg-accent transition">
            <Search className="w-4 h-4" />
            <span>Search tools...</span>
          </button>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-secondary transition"
          >
            <Menu className="w-6 h-6" />
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col gap-4">
              <Link to="/" className="text-sm font-medium text-foreground hover:text-primary transition">
                Home
              </Link>
              <div className="space-y-2">
                <p className="text-sm font-semibold text-muted-foreground">Categories</p>
                {categories.map((category) => (
                  <Link
                    key={category.id}
                    to={`/category/${category.slug}`}
                    className="block text-sm text-foreground hover:text-primary transition pl-4"
                  >
                    {category.name}
                  </Link>
                ))}
              </div>
              <Link to="/submit" className="text-sm font-medium text-foreground hover:text-primary transition">
                Submit Tool
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
