import { Link } from 'react-router-dom';
import { Star, TrendingUp, ExternalLink } from 'lucide-react';
import type { Tool } from '../lib/tools-data';

interface ToolCardProps {
  tool: Tool;
}

export default function ToolCard({ tool }: ToolCardProps) {
  return (
    <Link
      to={`/tool/${tool.slug}`}
      className="group block bg-card border border-border rounded-lg p-6 hover:shadow-lg hover:border-primary/50 transition-all duration-200"
    >
      {/* Image */}
      <div className="relative mb-4 aspect-video rounded-lg overflow-hidden bg-secondary">
        <img
          src={tool.image}
          alt={tool.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        {tool.trending && (
          <div className="absolute top-2 right-2 flex items-center gap-1 bg-primary text-white text-xs font-medium px-2 py-1 rounded-full">
            <TrendingUp className="w-3 h-3" />
            Trending
          </div>
        )}
      </div>

      {/* Content */}
      <div className="space-y-3">
        <div>
          <h3 className="font-bold text-lg text-foreground group-hover:text-primary transition mb-1">
            {tool.name}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {tool.tagline}
          </p>
        </div>

        <p className="text-sm text-foreground line-clamp-2">
          {tool.description}
        </p>

        {/* Meta */}
        <div className="flex items-center justify-between pt-3 border-t border-border">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="text-sm font-medium text-foreground">{tool.rating}</span>
            <span className="text-xs text-muted-foreground">({tool.reviewCount})</span>
          </div>
          <div className="flex items-center gap-1 text-primary text-sm font-medium">
            View Details
            <ExternalLink className="w-3 h-3" />
          </div>
        </div>

        {/* Pricing */}
        <div className="pt-2">
          <p className="text-xs text-muted-foreground">{tool.pricing}</p>
        </div>
      </div>
    </Link>
  );
}
