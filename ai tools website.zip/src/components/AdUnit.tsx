import { useEffect } from 'react';

interface AdUnitProps {
  slot: string;
  format?: 'auto' | 'rectangle' | 'vertical' | 'horizontal';
  className?: string;
}

export default function AdUnit({ slot, format = 'auto', className = '' }: AdUnitProps) {
  useEffect(() => {
    // Initialize AdSense ads
    try {
      // @ts-ignore
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (err) {
      console.log('AdSense error:', err);
    }
  }, []);

  return (
    <div className={`ad-container ${className}`}>
      {/* Replace data-ad-client with your AdSense publisher ID */}
      <ins
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
      
      {/* Fallback placeholder for development */}
      <div className="ad-placeholder bg-secondary border border-border rounded-lg flex items-center justify-center text-muted-foreground text-sm p-8">
        <div className="text-center">
          <p className="font-medium mb-1">Advertisement</p>
          <p className="text-xs">Replace with your AdSense code</p>
        </div>
      </div>
    </div>
  );
}
